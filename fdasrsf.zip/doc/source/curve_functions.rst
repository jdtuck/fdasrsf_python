Curve Functions
===============
.. automodule:: curve_functions
   :members:
