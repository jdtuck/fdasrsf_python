Functional Alignment
====================

.. automodule:: time_warping
   :members:

.. toctree::
   :maxdepth: 1