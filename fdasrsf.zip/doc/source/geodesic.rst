SRVF Geodesic Computation
=========================
.. automodule:: geodesic
   :members:
