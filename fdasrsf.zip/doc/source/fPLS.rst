Functional Principal Least Squares
==================================
.. automodule:: fPLS
   :members: