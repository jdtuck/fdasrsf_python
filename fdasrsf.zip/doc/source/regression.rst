Elastic Regression
==================

.. automodule:: regression
   :members:

.. toctree::
   :maxdepth: 1