Gaussian Generative Models
==========================

.. automodule:: gauss_model
   :members:

.. toctree::
   :maxdepth: 1