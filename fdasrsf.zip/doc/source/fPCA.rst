Functional Principal Component Analysis
=======================================
.. automodule:: fPCA
   :members: