double *r8mat_expm1 ( int n, double a[] );
double *r8mat_expm2 ( int n, double a[] );
double *r8mat_expm3 ( int n, double a[] );
